# Integrity Assistant 1.0.2 (Public Beta)

Integrity Assistant is your digital memory assistant that continuously monitors your digital activity, making it searchable and interactive through natural language.

## Installation

1. Run the installer script for your platform:
   - Windows: Double-click `install.bat`
   - macOS/Linux: Open a terminal and run `chmod +x install.sh && ./install.sh`

2. Launch Integrity Assistant:
   - Windows: Use the desktop shortcut or run `run_integrity.bat`
   - macOS/Linux: Use the application shortcut or run `./run_integrity.sh`

## Features

- **Digital Activity Monitoring**: Captures screenshots and records keystrokes to understand your digital activity
- **Advanced OCR**: Extracts text from screenshots to make all visual content searchable
- **Natural Language Interface**: Ask questions about your activity in everyday language
- **Privacy-First Design**: All processing happens locally with military-grade encryption

## Privacy & Security

All data is encrypted using AES-256 encryption. You can enable Privacy Mode at any time to pause all monitoring.

## Support

Need help? Contact our support team:
- Email: support@integrity-assistant.com
- Website: https://integrity-assistant.com
