#!/bin/bash

echo "Integrity Assistant 1.0.2 (Public Beta) Installer"
echo "==============================================="
echo

# Check for Python installation
if ! command -v python3 &> /dev/null; then
    echo "Python 3 is not installed or not in the PATH."
    echo "Please install Python 3.8 or higher."
    
    if [[ "$OSTYPE" == "darwin"* ]]; then
        echo "For macOS, you can install it using Homebrew: brew install python3"
    else
        echo "For Ubuntu/Debian: sudo apt-get install python3 python3-pip python3-venv"
        echo "For Fedora: sudo dnf install python3 python3-pip"
    fi
    
    exit 1
fi

# Check Python version
PYTHON_VERSION=$(python3 -c "import sys; print('{}.{}'.format(sys.version_info[0], sys.version_info[1]))")
PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d. -f1)
PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d. -f2)

if [ "$PYTHON_MAJOR" -lt 3 ] || ([ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 8 ]); then
    echo "Python 3.8 or higher is required, but Python $PYTHON_VERSION is installed."
    echo "Please upgrade your Python installation."
    exit 1
fi

echo "Installing required dependencies..."
echo "This may take a few minutes..."
echo

# Create and activate a virtual environment
python3 -m venv venv
source venv/bin/activate

# Upgrade pip
pip install --upgrade pip

# Install required packages
pip install -r requirements.txt

# Check for errors during installation
if [ $? -ne 0 ]; then
    echo
    echo "An error occurred during dependency installation."
    echo "Please check your internet connection and try again."
    exit 1
fi

# Create necessary directories
mkdir -p assets
mkdir -p logs
mkdir -p data
mkdir -p screenshots

echo
echo "Installation completed successfully!"
echo

# Create run script
cat > run_integrity.sh << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
source venv/bin/activate
python3 integrity_assistant.py
EOF

# Make run script executable
chmod +x run_integrity.sh

# Create desktop shortcut based on platform
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS
    echo "Creating application shortcut..."
    
    # Create Applications directory if it doesn't exist
    mkdir -p ~/Applications
    
    # Get absolute path of the installation directory
    INSTALL_DIR=$(cd "$(dirname "$0")" && pwd)
    
    # Create a simple AppleScript application
    cat > Integrity.applescript << EOF
tell application "Terminal"
    do script "cd "$INSTALL_DIR" && ./run_integrity.sh"
end tell
EOF
    
    # Compile the AppleScript
    osacompile -o ~/Applications/Integrity.app Integrity.applescript
    
    # Clean up the script
    rm Integrity.applescript
    
    echo "Shortcut created in ~/Applications/Integrity.app"
    
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Linux
    echo "Creating desktop shortcut..."
    
    # Get absolute path of the installation directory
    INSTALL_DIR=$(cd "$(dirname "$0")" && pwd)
    
    # Create .desktop file
    mkdir -p ~/.local/share/applications
    cat > ~/.local/share/applications/integrity-assistant.desktop << EOF
[Desktop Entry]
Type=Application
Name=Integrity Assistant
Comment=Digital Activity Assistant
Exec=$INSTALL_DIR/run_integrity.sh
Terminal=false
Categories=Utility;
EOF
    
    echo "Desktop shortcut created."
fi

echo
echo "You can now run Integrity Assistant by executing ./run_integrity.sh"
echo "or by using the shortcut created on your desktop/applications menu."
echo

# Make the script executable
chmod +x run_integrity.sh
